"""RXS Engine helper: export the loaded Blender file as a self-contained GLB.

Called by RXSEditor with:
  blender.exe --background <source.blend> --python export_blend_to_glb.py -- <output.glb>
"""
import bpy
import sys

args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
if not args:
    raise RuntimeError("RXS Engine did not provide an output GLB path.")

output_path = args[0]

# Pack external images into the Blender file before exporting, so the GLB can
# carry its material textures without depending on the original texture paths.
try:
    bpy.ops.file.pack_all()
except Exception:
    # Some files have no external image datablocks; the exporter can still run.
    pass

bpy.ops.export_scene.gltf(
    filepath=output_path,
    export_format="GLB",
    export_materials="EXPORT",
    export_image_format="AUTO",
    export_apply=True,
    export_texcoords=True,
    export_normals=True,
    export_tangents=True,
    export_cameras=False,
    export_lights=False,
    use_selection=False,
)
print("RXS Engine: exported Blender scene to", output_path)
